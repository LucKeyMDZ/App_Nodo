import datetime
from pathlib import Path

from fastapi import FastAPI, Request, Depends
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from sqlalchemy import text

from .database import get_db
from . import models
from .routers import prestamos, inventario, novedades

BASE_DIR = Path(__file__).resolve().parent

app = FastAPI(title="Préstamos del taller")

app.include_router(prestamos.router)
app.include_router(inventario.router)
app.include_router(novedades.router)

app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

CURSOS = ["1A", "1B", "2A", "2B", "3E", "3I", "4E", "4I", "5E", "5I", "6E", "6I"]
DIAS = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes"]


@app.get("/healthz")
def healthz(db: Session = Depends(get_db)):
    db.execute(text("SELECT 1"))
    return {"status": "ok"}


@app.get("/", response_class=HTMLResponse)
def mostrador(request: Request):
    return templates.TemplateResponse(
        request,
        "index.html",
        {
            "cursos": CURSOS,
            "dias": DIAS,
            "hoy": datetime.datetime.now().strftime("%H:%M"),
        },
    )


@app.get("/historial", response_class=HTMLResponse)
def historial_page(
    request: Request,
    curso: str = "",
    profesor: str = "",
    elemento_codigo: str = "",
    desde: str = "",
    hasta: str = "",
    estado: str = "",
    db: Session = Depends(get_db),
):
    q = db.query(models.Movimiento)
    if curso:
        q = q.join(models.Curso, models.Curso.id == models.Movimiento.id_curso).filter(
            models.Curso.nombre == curso
        )
    if profesor:
        q = q.filter(models.Movimiento.profesor_responsable.ilike(f"%{profesor}%"))
    if elemento_codigo:
        q = q.filter(models.Movimiento.elemento_codigo == elemento_codigo)
    if estado:
        q = q.filter(models.Movimiento.estado == estado)
    if desde:
        q = q.filter(models.Movimiento.fecha_hora >= desde)
    if hasta:
        q = q.filter(models.Movimiento.fecha_hora <= hasta + " 23:59:59")
    movimientos = q.order_by(models.Movimiento.fecha_hora.desc()).limit(500).all()

    return templates.TemplateResponse(
        request,
        "historial.html",
        {
            "movimientos": movimientos,
            "cursos": CURSOS,
            "filtros": {
                "curso": curso, "profesor": profesor, "elemento_codigo": elemento_codigo,
                "desde": desde, "hasta": hasta, "estado": estado,
            },
        },
    )


@app.get("/inventario", response_class=HTMLResponse)
def inventario_page(request: Request, q: str = "", estado: str = "", db: Session = Depends(get_db)):
    query = db.query(models.Inventario)
    if estado:
        query = query.filter(models.Inventario.estado == estado)
    if q:
        query = query.filter(
            (models.Inventario.nombre.ilike(f"%{q}%")) | (models.Inventario.codigo.ilike(f"%{q}%"))
        )
    elementos = query.order_by(models.Inventario.nombre).limit(1000).all()
    return templates.TemplateResponse(
        request,
        "inventario.html",
        {"elementos": elementos, "q": q, "estado": estado},
    )


@app.get("/novedades", response_class=HTMLResponse)
def novedades_page(request: Request, db: Session = Depends(get_db)):
    novedades_list = db.query(models.Novedad).order_by(models.Novedad.fecha_hora.desc()).limit(200).all()
    return templates.TemplateResponse(
        request, "novedades.html", {"novedades": novedades_list}
    )
