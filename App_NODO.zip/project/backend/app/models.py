from sqlalchemy import (
    Column, Integer, String, Text, ForeignKey, TIMESTAMP, CheckConstraint
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from .database import Base


class Curso(Base):
    __tablename__ = "cursos"
    id = Column(Integer, primary_key=True)
    nombre = Column(Text, unique=True, nullable=False)


class Materia(Base):
    __tablename__ = "materias"
    id = Column(Integer, primary_key=True)
    nombre = Column(Text, unique=True, nullable=False)


class Profesor(Base):
    __tablename__ = "profesores"
    id = Column(Integer, primary_key=True)
    nombre = Column(Text, unique=True, nullable=False)
    telefono = Column(Text, nullable=True)


class Horario(Base):
    __tablename__ = "horarios"
    id_horario = Column(Integer, primary_key=True)
    id_curso = Column(Integer, ForeignKey("cursos.id"), nullable=False)
    id_materia = Column(Integer, ForeignKey("materias.id"), nullable=False)
    id_profesor = Column(Integer, ForeignKey("profesores.id"), nullable=False)
    dia = Column(Text, nullable=False)
    hora_inicio = Column(Text, nullable=False)
    hora_fin = Column(Text, nullable=False)

    curso = relationship("Curso")
    materia = relationship("Materia")
    profesor = relationship("Profesor")


class Inventario(Base):
    __tablename__ = "inventario"
    codigo = Column(Text, primary_key=True)
    nombre = Column(Text, nullable=False)
    categoria = Column(Text, nullable=True)
    estado = Column(Text, nullable=False, default="disponible")

    __table_args__ = (
        CheckConstraint("estado IN ('disponible','prestado','reparacion','baja')"),
    )


class Movimiento(Base):
    __tablename__ = "movimientos"
    id = Column(Integer, primary_key=True)
    fecha_hora = Column(TIMESTAMP, nullable=False, server_default=func.now())
    tipo_actividad = Column(Text, nullable=False)

    id_curso = Column(Integer, ForeignKey("cursos.id"), nullable=True)
    dia = Column(Text, nullable=True)
    evento_nombre = Column(Text, nullable=True)

    profesor_responsable = Column(Text, nullable=False)
    cargado_por = Column(Text, nullable=True)

    elemento_codigo = Column(Text, ForeignKey("inventario.codigo"), nullable=False)
    hora_devolver = Column(Text, nullable=False)
    fecha_hora_devolucion_real = Column(TIMESTAMP, nullable=True)

    estado = Column(Text, nullable=False, default="prestado")
    anotaciones = Column(Text, nullable=True)

    curso = relationship("Curso")
    elemento = relationship("Inventario")

    __table_args__ = (
        CheckConstraint("tipo_actividad IN ('clase','evento')"),
        CheckConstraint("estado IN ('prestado','devuelto','vencido')"),
    )


class Novedad(Base):
    __tablename__ = "novedades"
    id = Column(Integer, primary_key=True)
    fecha_hora = Column(TIMESTAMP, nullable=False, server_default=func.now())
    elemento_codigo = Column(Text, ForeignKey("inventario.codigo"), nullable=False)
    clasificacion = Column(Text, nullable=False)
    comentario = Column(Text, nullable=True)

    elemento = relationship("Inventario")
