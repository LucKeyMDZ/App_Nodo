from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db

router = APIRouter(prefix="/api", tags=["inventario"])


@router.get("/elementos/{codigo}", response_model=schemas.ElementoOut)
def obtener_elemento(codigo: str, db: Session = Depends(get_db)):
    elemento = db.query(models.Inventario).filter(models.Inventario.codigo == codigo).first()
    if not elemento:
        raise HTTPException(404, f"No existe ningún elemento con el código {codigo!r}")
    return elemento


@router.get("/inventario", response_model=list[schemas.ElementoOut])
def listar_inventario(estado: str | None = None, q: str | None = None, db: Session = Depends(get_db)):
    query = db.query(models.Inventario)
    if estado:
        query = query.filter(models.Inventario.estado == estado)
    if q:
        query = query.filter(
            (models.Inventario.nombre.ilike(f"%{q}%")) | (models.Inventario.codigo.ilike(f"%{q}%"))
        )
    return query.order_by(models.Inventario.nombre).limit(1000).all()
