from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models
from ..database import get_db
from .. import schemas

router = APIRouter(prefix="/api", tags=["novedades"])

CLASIFICACIONES_QUE_DAN_DE_BAJA = {"retiro", "baja"}


@router.post("/novedades")
def crear_novedad(body: schemas.NovedadCreate, db: Session = Depends(get_db)):
    elemento = db.query(models.Inventario).filter(
        models.Inventario.codigo == body.elemento_codigo
    ).first()
    if not elemento:
        raise HTTPException(404, f"No existe ningún elemento con el código {body.elemento_codigo!r}")

    novedad = models.Novedad(
        elemento_codigo=body.elemento_codigo,
        clasificacion=body.clasificacion,
        comentario=body.comentario,
    )
    db.add(novedad)

    if body.clasificacion.lower() in CLASIFICACIONES_QUE_DAN_DE_BAJA:
        elemento.estado = "baja"
    elif body.clasificacion.lower() in ("reparacion", "reparación"):
        elemento.estado = "reparacion"

    db.commit()
    db.refresh(novedad)
    return {
        "id": novedad.id,
        "elemento_codigo": novedad.elemento_codigo,
        "clasificacion": novedad.clasificacion,
        "comentario": novedad.comentario,
        "estado_elemento": elemento.estado,
    }


@router.get("/novedades")
def listar_novedades(db: Session = Depends(get_db)):
    novedades = db.query(models.Novedad).order_by(models.Novedad.fecha_hora.desc()).limit(500).all()
    return [
        {
            "id": n.id,
            "fecha_hora": n.fecha_hora,
            "elemento_codigo": n.elemento_codigo,
            "elemento_nombre": n.elemento.nombre if n.elemento else None,
            "clasificacion": n.clasificacion,
            "comentario": n.comentario,
        }
        for n in novedades
    ]
