# Préstamos del taller

Sistema local para reemplazar el `Stock.xlsm`: registra préstamos y devoluciones de
elementos del taller, busca automáticamente el profesor a cargo según curso + día + hora,
y mantiene un historial completo para auditoría.

Corre entero en tu red interna, sin depender de internet. Backend en FastAPI (Python).
Para probarlo alcanza con Python y SQLite; para el despliegue real en el servidor del
trabajo usa PostgreSQL en Docker.

## Estructura

```
├── docker-compose.yml
├── .env.example
├── db/
│   ├── schema.sql        # tablas
│   └── seed.sql           # cursos, materias, profesores, horarios, inventario y novedades iniciales
└── backend/
    ├── Dockerfile
    ├── requirements.txt        # para el despliegue con Docker/Postgres
    ├── requirements-local.txt  # para probar en Windows con SQLite (sin psycopg2)
    └── app/
        ├── main.py         # rutas de las páginas HTML
        ├── database.py
        ├── models.py       # tablas como modelos SQLAlchemy
        ├── schemas.py      # validación de datos de entrada/salida
        ├── routers/        # API: prestamos, inventario, novedades
        ├── templates/       # páginas HTML (mostrador, historial, inventario, novedades)
        └── static/style.css
```

## Uso

- **Mostrador** (`/`): escaneás el código con el lector QR. Si el elemento está afuera,
  te ofrece marcarlo como devuelto. Si está disponible, te arma el formulario de préstamo:
  elegís *Clase regular* (se busca solo el profesor por curso/día/hora) o *Evento especial*
  (cargás el nombre y el responsable a mano).
- **Historial** (`/historial`): buscador de todos los movimientos, por curso, profesor,
  código, fecha o estado.
- **Inventario** (`/inventario`): estado de cada elemento (disponible, prestado, en
  reparación, de baja).
- **Novedades** (`/novedades`): registrar una baja, reparación o incidente. Si la
  clasificación es "retiro", el elemento pasa a estado `baja` automáticamente.

## Probar en Windows, sin Docker

Para probarlo en tu PC (Windows 10) antes de subirlo al servidor:

1. **Instalá Python 3.11 o más nuevo** si no lo tenés: https://www.python.org/downloads/
   Durante la instalación, tildá la casilla **"Add python.exe to PATH"**.

2. Descomprimí este zip en cualquier carpeta.

3. Doble clic en **`run_local.bat`** (o abrilo desde una consola: `run_local.bat`).
   La primera vez va a crear un entorno virtual, instalar las dependencias y armar la
   base de datos local (`backend\local.db`, en SQLite — no hace falta instalar nada más).

4. Cuando la consola diga `Application startup complete`, abrí en el navegador:
   ```
   http://localhost:8000
   ```

5. Para cortarlo: `Ctrl+C` en la consola. Para volver a levantarlo después, corré
   `run_local.bat` de nuevo (no vuelve a pedir instalar nada si ya está el entorno creado).

Si en algún momento querés arrancar de cero con los datos originales (perdés lo que
hayas cargado probando):
```
python init_local_db.py
```

**Nota:** esto usa SQLite en vez de Postgres, así que es solo para probar el
funcionamiento. Para el despliegue real en el servidor del trabajo, seguí con Docker
como se explica más abajo — ahí sí se usa Postgres.

## Despliegue en el servidor (Docker + Postgres)

### Requisitos en el servidor

- Docker y Docker Compose (plugin `docker compose`, no el viejo `docker-compose`).
- Puerto 8000 libre (o cambiá el mapeo en `docker-compose.yml`).

### Instalación

1. Copiá esta carpeta entera al servidor Linux (por ejemplo con `scp -r` o `git clone` si la subís a un repo propio).

2. Configurá la contraseña de la base de datos:
   ```bash
   cp .env.example .env
   nano .env   # cambiá DB_PASSWORD
   ```

3. Levantá todo:
   ```bash
   docker compose up -d --build
   ```
   La primera vez, Postgres va a crear las tablas y cargar todos los datos (horarios 2026,
   inventario, novedades) automáticamente a partir de `db/schema.sql` y `db/seed.sql`.

4. Verificá que esté vivo:
   ```bash
   curl http://localhost:8000/healthz
   ```
   Debería devolver `{"status":"ok"}`.

5. Abrí `http://IP_DEL_SERVIDOR:8000` desde cualquier PC de la red de la escuela.

### Backups

El postgres oficial solo ejecuta los `.sql` de `db/` **la primera vez**, cuando el volumen
está vacío. Para backups periódicos del contenido real, un cron simple alcanza:

```bash
docker compose exec -T db pg_dump -U prestamos prestamos > backup_$(date +%F).sql
```

### Si necesitás volver a cargar la semilla desde cero

```bash
docker compose down -v   # ¡borra los datos actuales!
docker compose up -d --build
```

## Notas sobre este entrega

- El esquema de datos y la lógica de búsqueda (curso + día + hora → profesor) los probé
  aparte, cargando `schema.sql` + `seed.sql` reales en una base de prueba y corriendo el
  flujo completo de préstamo y devolución — así que confío en que los datos y las consultas
  están bien.
- Lo que **no pude probar** acá es el stack completo corriendo con Docker (esta máquina
  no tiene Docker ni acceso a internet para bajar las imágenes). El código de FastAPI está
  escrito con cuidado y revisado, pero puede aparecer algún detalle al levantarlo por primera
  vez en tu servidor. Si pasa algo, pegame el error y lo resolvemos.
- El campo `categoria` del inventario quedó vacío (`NULL`) para los 207 elementos migrados:
  el Excel original no tenía esa columna, así que no quise inventarla. Se puede completar
  después, a mano o en bloque si me pasás un criterio.
- El historial (`movimientos`) arranca vacío a propósito: el `diario` viejo no registraba
  si un elemento ya había sido devuelto, así que no había forma de migrar el estado actual
  con confianza. El `Stock.xlsm` te queda como archivo histórico de referencia.
- La hoja `PUERTA` no se incluyó (guardias de recreo/comedor, no un curso).
- La base local (`backend/local.db`, SQLite) y la del servidor (Postgres) son
  independientes: lo que cargues probando en tu PC no viaja solo al servidor. Cuando
  despliegues en Docker, arranca de nuevo con los datos de `seed.sql`.
